Ext.namespace('Ext.funkylab');

Ext.funkylab.showAlert=function(alertTitle,alertMsg,class_){
	var classbox = class_ ? class_ : 'ext-mb-error';
	Ext.MessageBox.show({
        width:300,
		title:alertTitle,
		msg:alertMsg,
		buttons: Ext.MessageBox.OK,
		icon: classbox
	});
}

Ext.funkylab.install = {
	step:0,
	callBackCheck:null,
	Window:null,
	card:null,
	validNext:null,
	navHandler : function(direction){
		if(this.callBackCheck!=null)
		
		this.callBackCheck();
		if(direction==-1){
			this.step--;
			this.step = this.step<0 ? 0 : this.step;
			Ext.getCmp('move-next').enable();
			if(this.step==0)
				Ext.getCmp('move-prev').disable();
		}else if(direction==1 && this.validNext==true){
			this.step++;
			this.step = this.step>this.card.items.items.length ? 0 : this.step;
			Ext.getCmp('move-prev').enable();
			if(this.step==this.card.items.items.length-1)
				Ext.getCmp('move-next').disable();
		}
		this.card.layout.setActiveItem(this.step);
	},
	createCard:function(){
		if(this.card==null){
			var allSteps = new Array();			
//----------------------------------------------------------------------------------
// Step 1
//----------------------------------------------------------------------------------
			var step1 = new Ext.Panel({ title:'1 / 4 - Pr�sentation', autoLoad:'os/html/step1.html' });
		   	step1.on('beforeshow',function(){ Ext.funkylab.install.validNext=true; });
			allSteps.push(step1);
//----------------------------------------------------------------------------------
// Step 2
//----------------------------------------------------------------------------------

			var step2 = new Ext.Panel({ title:"2 / 4 - Conditions d'utilisation", autoLoad:'os/html/step2.html' });
		   	step2.on('beforeshow',function(){ Ext.funkylab.install.validNext=true; });
			step2.on('beforeshow',function(){
				Ext.funkylab.install.callBackCheck=function(){
					Ext.funkylab.install.validNext=true;
					if(Ext.get('conditions').dom.checked==false){
						Ext.funkylab.install.validNext=false;
						Ext.funkylab.showAlert("Alerte","Veuillez accepter les conditions d'utilisation");
					}
				}
			});
			allSteps.push(step2);			
					
//----------------------------------------------------------------------------------
// Step 3
//----------------------------------------------------------------------------------
			
		   	var step3 = new Ext.form.FormPanel({
			   	title:'3 / 4 - Configuration',
			   	id:'ConfigPanel',
			   	items:[
			   		 {html:'<h1>Configuration du site</h1><br/>'}
			   		,new Ext.form.TextField({fieldLabel:'Url',anchor:'95%',name:'url'})
			   		,{html:'<br/><h1>Configuration Mysql</h1><br/>'}
			   		,new Ext.form.TextField({fieldLabel:'Host',anchor:'95%',name:'host'})
			   		,new Ext.form.TextField({fieldLabel:'Login',anchor:'95%',name:'login'})
			   		,new Ext.form.TextField({fieldLabel:'Mot de passe',anchor:'95%', inputType:'password',name:'password'})
			   		,new Ext.form.TextField({fieldLabel:'Table',anchor:'95%',name:'table'})
			   	]
			});
	    	step3.on('beforeshow',function(){
				Ext.funkylab.install.callBackCheck=function(){
					Ext.funkylab.install.validNext=false;
					Ext.funkylab.install.installServer();
				}
			});
			allSteps.push(step3);
//----------------------------------------------------------------------------------
// Step 4
//----------------------------------------------------------------------------------
		
			var step4 = new Ext.Panel({ title:"4 / 4 Fin d'installation", autoLoad:'os/html/step4.html' });
			allSteps.push(step4);
			
//----------------------------------------------------------------------------------
// Card
//----------------------------------------------------------------------------------
		
			this.card = new Ext.Panel({
			    layout:'card',
			    width:420,
			    region:'east',
			    activeItem: this.step,
			    defaults: {
					bodyBorder:false,
					border:false,
				    bodyStyle: 'padding:15px',
				    frame:true
				},
			    bbar: [
			       '->',{
			            id: 'move-prev',
			            text: 'Retour',
			            handler: function(){
				            Ext.funkylab.install.callBackCheck=null;
				            Ext.funkylab.install.navHandler(-1);
			            },
			            disabled: true
			        },{
			            id: 'move-next',
			            text: 'Continuer',
			            handler: Ext.funkylab.install.navHandler.createDelegate(this, [1])
			        }
			    ],
			    items: allSteps
			});
		}
	},
	installServer:function(){
		var objSave = Ext.getCmp('ConfigPanel').getForm().getValues();
		for(b in objSave){
			if(objSave[b]==""){
				Ext.funkylab.showAlert("Alerte","Veuillez remplir tout les champs");
				return false;
			}
		}
		Ext.getCmp('move-prev').disable();
		Ext.getCmp('move-next').disable();
		Ext.funkylab.progressbar=Ext.MessageBox.wait('En cours...','Installation', {});
		Ext.Ajax.request({
        	url:'os/php/install.php', 
			params:objSave,
			success: function(e) {
				Ext.funkylab.progressbar.hide();
				if(e.responseText==1){
					Ext.funkylab.install.validNext=true;
					Ext.funkylab.install.card.layout.setActiveItem(Ext.funkylab.install.card.items.items.length-1);
				}else{
					Ext.getCmp('move-prev').enable();
			 		Ext.getCmp('move-next').enable();
					Ext.funkylab.showAlert("Alerte","Erreur de cr�ation du site");
				}
			}
		});
	},
	makeWindow:function(){
		if(this.Window==null){
			this.createCard();
			var win = new Ext.Window({
				title:'Installation',
				id:'winInstall',
			   	width:640, 
			   	height:440,
			    resizable:false,
			    minimizable:false,
			    closable:false,
			    maximizable:false,
			    draggable:false,
			    layout:'border',
			    items:[
			    	{
				        region: 'center',
				        collapsible: false,
				        split: false,
				        frame:true,
				        html:'<img src="os/resources/images/install.png" />'
					},this.card
			    ]
		    });
		    this.Window = win;
	    }
	},
	start:function(){
		this.makeWindow();
		this.Window.show()
	}
};

Ext.onReady(function(){
	Ext.QuickTips.init();
	Ext.BLANK_IMAGE_URL = 'os/resources/images/default/s.gif';
    (function(){
		Ext.get('loading').remove();
		Ext.get('loading-mask').fadeOut({remove:true});
		Ext.funkylab.install.start();
		window.onresize=function(){
			Ext.funkylab.install.Window.center();
		}
    }).defer(250);
});