var files = [		
		// CSS
	     "http://extjs.cachefly.net/ext-2.2.1/resources/css/ext-all.css"
	    ,"os/resources/css/xtheme-gray.css"
	    ,"os/resources/css/custom.css"
		// JS
		 ,"http://extjs.cachefly.net/builds/ext-cdn-771.js"
	    
];	    

for(xx=0;xx<files.length;xx++){
	var pourcentage = Math.round((xx/files.length)*100);
	document.write('<script type="text/javascript">document.getElementById("loading-msg").innerHTML = "Loading '+pourcentage+'%";</script>');
	if(files[xx].indexOf(".css")!=-1){
		document.write('<link rel="stylesheet" type="text/css" href="'+files[xx]+'"/>');
	}else{
		document.write('<script type="text/javascript" src="'+files[xx]+'"></script>');	
	}
	document.write('<script type="text/javascript">document.getElementById("loading-msg").innerHTML = "Loading 100%";</script>');
}		