<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
	<head>
		<title>!!!</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<link rel="icon" href="favicon.ico" type="image/x-icon" />
		<style type="text/css">
			html, body {
				background:#b6c2d1 url('os/resources/wallpapers/wall3.gif')  repeat-x top center;
			    font: normal 12px tahoma, arial, verdana, sans-serif;
				margin: 0;
				padding: 0;
				border: 0 none;
				overflow: hidden;
				height: 100%;
			}
			#loading-mask{
			    position:absolute;
			    left:0;
			    top:0;
			    width:100%;
			    height:100%;
			    z-index:20000;
			    background:white;
			}
			#loading{
			    position:absolute;
			    left:47%;
			    top:45%;
			    padding:2px;
			    z-index:20001;
			    height:auto;
			}
			#loading img{
			    padding-left:2px;
			}
			#loading a {
			    color:#225588;
			}
			#loading .loading-indic{
			    color:white;
			    font:bold 13px tahoma,arial,helvetica;
			    margin:0;
			    height:auto;
			    text-align:center;
			}
			#loading-msg {
			    color:black;
			    clear:both;
			    font: normal 10px arial,tahoma,sans-serif;
			}
			
		</style>
	</head>
	<body>
		
		<!-- LOADING -->
		<div id="loading-mask"></div>
		<div id="loading">
			<img src="os/resources/images/logof4.gif" alt="logo" />
		    <div class="loading-indic">
		    	<span id="loading-msg">Loading...</span>
		    </div>
		</div>
		
		<script type="text/javascript" src="os/js/init.js"></script>
		<script type="text/javascript" src="os/js/install.js"></script>
	</body>
</html>